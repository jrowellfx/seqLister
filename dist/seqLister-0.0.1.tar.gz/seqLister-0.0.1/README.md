# About seqLister

`seqLister` is a python package to help (docn coming - wip)

## How to install the seqLister module on your system.

To install these commands on your system follow these steps (you need root
privileges).

1)  tbd (wip)
