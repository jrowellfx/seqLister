# About seqLister

`seqLister` is a python library for expanding and condensing integer-sequences using a simple syntax widely used within the VFX-industry for specifying frame-ranges.

## How to install the seqLister module on your system.

python3 -m pip install seqLister
